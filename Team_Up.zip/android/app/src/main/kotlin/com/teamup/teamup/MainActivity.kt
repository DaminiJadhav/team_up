package com.sdaemon.teamup

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
