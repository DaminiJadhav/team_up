import 'package:hexcolor/hexcolor.dart';
import 'package:flutter/material.dart';

class Palatte{
  Color blue  = Hexcolor('#2d63d7');
  Color white = Hexcolor('#ffff');
} 